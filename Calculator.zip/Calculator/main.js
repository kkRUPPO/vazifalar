const f1=document.querySelector(".f1")
const h1=document.querySelector(".h1")

f1.addEventListener("submit", evt=>{
    evt.preventDefault()
    const son1=Number(evt.target.son1.value)
    const son2=Number(evt.target.son2.value)
    const amal=evt.target.amal.value

    if(amal=="+") {
        h1.textContent=son1+son2
    }
    if(amal=="-") {
        h1.textContent=son1-son2
    }
    if(amal=="*") {
        h1.textContent=son1*son2
    }
    if(amal=="/") {
        h1.textContent=son1/son2
    }
    if(amal=="^") {
        h1.textContent=son1*son1
    }
    if(amal=="3") {
        h1.textContent=son1*son1*son1
    }
    if(amal=="4") {
        h1.textContent=son1*son1*son1*son1
    }
    if(amal=="5") {
        h1.textContent=son1*son1*son1*son1*son1
    }
    if(amal=="6") {
        h1.textContent=son1*son1*son1*son1*son1*son1
    }
    if(amal=="7") {
        h1.textContent=son1*son1*son1*son1*son1*son1*son1
    }
    if(amal=="8") {
        h1.textContent=son1*son1*son1*son1*son1*son1*son1*son1
    }
    if(amal=="9") {
        h1.textContent=son1*son1*son1*son1*son1*son1*son1*son1*son1
    }
    
    if(amal=="10") {
        h1.textContent=son1*son1*son1*son1*son1*son1*son1*son1*son1*son1
    }
    // alert("Bizga ishonganingiz uchun rahmat ✔")
})